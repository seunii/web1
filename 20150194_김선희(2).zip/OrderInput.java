import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class OrderInput extends HttpServlet {

	public void doGet(HttpServletRequest req, HttpServletResponse res)
		throws ServletException, IOException {
			doPost(req,res);
		}

	public void doPost(HttpServletRequest req, HttpServletResponse res)
		throws IOException, ServletException {
	
		res.setContentType("text/html;charset=KSC5601");
		PrintWriter out = res.getWriter();
		out.println("<html>");
       		out.println("<head>");
		out.println("<script  type='text/javascript' src=OrderInput.js></script>");
		out.println("<title>���� �ֹ��ϱ�</title>");
		out.println("</head>");
		out.println("<body>");
		out.println("<h2>���� �ֹ��ϱ�</h2>");
		out.println("<form onsubmit='return check()' method=post action=OrderConfirm id='pizza' target='w'>");
		out.println("<p><label>���� �̸�: <input name='custname' placeholder=ȫ�浿></label></p>");
		out.println("<p><label>��ȭ ��ȣ: <input type=tel name='custtel' placeholder=010-0000-0000></label></p>");
		out.println("<p><label>���� �ּ�: <input type=email name='custemail' placeholder=email@example.com></label></p>");
		out.println("<fieldset>");
		out.println("<legend> ���� ũ�� ���� </legend>");
		out.println("<label> <input type=radio name='size' value=small> Small </label>");
		out.println("<label> <input type=radio name='size' value=medium> Medium </label>");
		out.println("<label> <input type=radio name='size' value=large> Large </label>");
		out.println("</fieldset>");
		out.println("<br>");
		out.println("<fieldset>");
		out.println("<legend> ���� ���� ������ </legend>");
		out.println("<label> <input type=checkbox name='topping' value=bacon> ������ </label>");
		out.println("<label> <input type=checkbox name='topping' value=cheese> ġ�� </label>");
		out.println("<label> <input type=checkbox name='topping' value=onion> ���� </label>");
		out.println("<label> <input type=checkbox name='topping' value=mushroom> ���� </label>");
		out.println("</fieldset>");
		out.println("<br>");
		out.println("<label>���ϴ� ��� �ð�: <input type=time min=11:00 max=21:00 step=900 name='delivery' placeholder=11:00~21:00����></label><br>");
		out.println("<label>��޽� �䱸 ����: <textarea name='comments' placeholder=��޽ÿ䱸����></textarea></label>");
		out.println("<br><br>");		
		out.println("<input type = submit value=�����ֹ��ϱ�>");
		out.println("</form>");
		out.println("</body>");
		out.println("</html>");
		out.close();
	}
}